package br.senai.controller;

import br.senai.model.Login;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;

public class LoginController {

    @PostMapping("/login/save")
    public String save(Login login, Model model){
        try{
            loginService.save(login);
            model.addAttribute("logins", login);
            model.addAttribute("isSave", true);
            return "./cadastrar";
        } catch (Exception e){
            model.addAttribute("logins", login);
            model.addAttribute("isError", true);
            model.addAttribute("errorMsg",e.getMessage());

            return "./cadastrar";
        }
    }
}

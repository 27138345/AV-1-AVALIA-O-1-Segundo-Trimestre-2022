package br.senai.model;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

public class Login {
    @Size(max = 100)
    private String email;
    @Size(max = 10)
    private String senha;

    @ManyToMany(mappedBy = "logins")
    private List<Login> logins;

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public List<Login> getEventos() {
        return logins;
    }
    public void setEventos(List<Evento> eventos) {
        this.logins = logins;
    }
    public String getSenha() {
        return senha;
    }
    public void setSenha(String senha) {
        this.senha = senha;
    }

    @Override
    public String toString() {
        return "Cliente{" +
                "email:" + email +
                "senha:" + senha;
    }

}

package br.senai.repository;

import br.senai.model.Login;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LoginRepository extends JpaRepository<Login, Long>{
    public Login findByNome(String nome);
    public Login findByEmail(String email);
    public Login findByEmailAndSenha(String email, String senha);

    public Login findBySenha(String senha);
}

package br.senai.service;

import br.senai.model.Cliente;

import javax.validation.constraints.Email;
import java.util.List;

public interface ClienteService {

    public List<Cliente> findAll();
    public Cliente findById(Long id);
    public Cliente findByNome(String nome);
    public Cliente save(Cliente cliente);
    public void deleteById(Long id);
    public  Cliente findByEmailandSenha(String email, String senha);
    public Cliente findByEmail(String email);
    public Cliente findBySenha(String senha);

    Cliente login(Cliente cliente);
}
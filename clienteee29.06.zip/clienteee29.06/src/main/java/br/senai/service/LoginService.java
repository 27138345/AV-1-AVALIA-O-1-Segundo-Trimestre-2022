package br.senai.service;

import br.senai.model.Cliente;
import br.senai.model.Login;

public interface LoginService {
    public Login save(Cliente cliente);
    public Login login(Cliente cliente);
    public Login email(String email);
    public Login senha(String senha);
    public Login findByEmail(String email);
    public Login findBySenha(String senha);

}

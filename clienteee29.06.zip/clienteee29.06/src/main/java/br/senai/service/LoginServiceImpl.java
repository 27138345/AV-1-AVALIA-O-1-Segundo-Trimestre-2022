package br.senai.service;

import br.senai.model.Cliente;
import br.senai.model.Login;
import br.senai.repository.LoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;

import java.util.List;

public class LoginServiceImpl {


    @Autowired
    LoginRepository loginRepository;

    public List<Login> findAll() {
        return loginRepository.findAll(Sort.by("email"));
    }

    @Override
    public Login findByEmail(String email) {
        return loginRepository.findByEmail(email);
    }

    @Override
    public Login findBySenha(String senha) {
        return loginRepository.findBySenha(senha);
    }

    @Override
    public Login save(Login login) {
        try {
            return loginRepository.save(login);
        } catch (Exception e) {
            throw e;
        }
    }

    @Override
    public Login findByEmailandSenha(String email, String senha) {
        return loginRepository.findByEmailAndSenha(email, senha);
    }
}
